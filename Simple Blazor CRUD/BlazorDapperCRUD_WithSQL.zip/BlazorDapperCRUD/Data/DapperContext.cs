﻿using System.Data;
using Microsoft.Data.SqlClient;


namespace BlazorDapperCRUD.Data
{
    public class DapperContext
    {
        private  string _connectionString;
        public DapperContext(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IDbConnection CreateConnection()
       => new SqlConnection(_connectionString);

    }
}
